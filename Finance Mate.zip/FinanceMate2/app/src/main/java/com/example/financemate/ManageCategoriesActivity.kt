package com.example.financemate

import android.os.Bundle
import android.widget.*
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity

class ManageCategoriesActivity : AppCompatActivity() {

    private lateinit var db: DatabaseHelper
    private var userId: Int = -1
    private lateinit var rgType: RadioGroup
    private lateinit var listView: ListView
    private lateinit var btnAdd: Button
    private var currentType = "IN"

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_manage_categories)

        // Enable back button
        supportActionBar?.setDisplayHomeAsUpEnabled(true)
        supportActionBar?.title = "Manage Categories"

        db = DatabaseHelper(this)

        // Get userId from intent
        userId = intent.getIntExtra("USER_ID", -1)
        if (userId == -1) {
            Toast.makeText(this, "Error: User not found", Toast.LENGTH_SHORT).show()
            finish()
            return
        }
        rgType = findViewById(R.id.rgCategoryType)
        listView = findViewById(R.id.listCategories)
        btnAdd = findViewById(R.id.btnAddCategory)

        // Back button
        findViewById<Button>(R.id.btnBackArrow).setOnClickListener {
            finish()
        }

        // Load income categories by default
        loadCategories()

        // Type selection listener
        rgType.setOnCheckedChangeListener { _, checkedId ->
            currentType = if (checkedId == R.id.rbIncomeCategory) "IN" else "OUT"
            loadCategories()
        }

        // Add category button
        btnAdd.setOnClickListener {
            showAddCategoryDialog()
        }

        // Delete category on long press
        listView.setOnItemLongClickListener { _, _, position, _ ->
            val category = listView.getItemAtPosition(position) as String
            showDeleteConfirmation(category)
            true
        }
    }

    private fun loadCategories() {
        val categories = db.getCategoriesByType(userId, currentType)
        listView.adapter = ArrayAdapter(
            this,
            android.R.layout.simple_list_item_1,
            categories
        )
    }

    private fun showAddCategoryDialog() {
        val input = EditText(this)
        input.hint = "Category name"

        AlertDialog.Builder(this)
            .setTitle("Add Category")
            .setView(input)
            .setPositiveButton("Add") { _, _ ->
                val name = input.text.toString().trim()
                if (name.isNotEmpty()) {
                    db.insertCategory(userId, name, currentType)
                    loadCategories()
                    Toast.makeText(this, "Category added", Toast.LENGTH_SHORT).show()
                }
            }
            .setNegativeButton("Cancel", null)
            .show()
    }

    private fun showDeleteConfirmation(category: String) {
        AlertDialog.Builder(this)
            .setTitle("Delete Category")
            .setMessage("Delete '$category'?")
            .setPositiveButton("Delete") { _, _ ->
                db.deleteCategory(userId, category, currentType)
                loadCategories()
                Toast.makeText(this, "Category deleted", Toast.LENGTH_SHORT).show()
            }
            .setNegativeButton("Cancel", null)
            .show()
    }

    override fun onSupportNavigateUp(): Boolean {
        finish()
        return true
    }
}