package com.example.financemate

data class Category(
    val name: String,
    val total: Double
)

data class CategorySummary(
    val categoryName: String,
    val total: Double
)