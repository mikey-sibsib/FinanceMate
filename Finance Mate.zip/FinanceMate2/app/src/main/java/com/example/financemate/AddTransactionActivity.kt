package com.example.financemate

import android.app.DatePickerDialog
import android.content.Intent
import android.os.Bundle
import android.widget.*
import androidx.appcompat.app.AppCompatActivity
import java.text.SimpleDateFormat
import java.util.*

class AddTransactionActivity : AppCompatActivity() {

    private lateinit var db: DatabaseHelper
    private var userId: Int = -1
    private lateinit var etDate: EditText
    private lateinit var spinnerCategory: Spinner
    private lateinit var rgType: RadioGroup
    private lateinit var rbIncome: RadioButton
    private lateinit var rbExpense: RadioButton
    private lateinit var etAmount: EditText
    private lateinit var etNote: EditText
    private lateinit var btnSave: Button
    private lateinit var btnManageCategories: Button

    private var selectedDate = ""
    private val calendar = Calendar.getInstance()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_add_transaction)

        // Enable back button
        supportActionBar?.setDisplayHomeAsUpEnabled(true)
        supportActionBar?.title = "Add Transaction"
        db = DatabaseHelper(this)

        // Get userId from intent
        userId = intent.getIntExtra("USER_ID", -1)
        if (userId == -1) {
            Toast.makeText(this, "Error: User not found", Toast.LENGTH_SHORT).show()
            finish()
            return
        }
        // Initialize views
        etDate = findViewById(R.id.etDate)
        spinnerCategory = findViewById(R.id.spinnerCategory)
        rgType = findViewById(R.id.rgTransactionType)
        rbIncome = findViewById(R.id.rbIncome)
        rbExpense = findViewById(R.id.rbExpense)
        etAmount = findViewById(R.id.etAmount)
        etNote = findViewById(R.id.etNote)
        btnSave = findViewById(R.id.btnSave)
        btnManageCategories = findViewById(R.id.btnManageCategories)

        findViewById<Button>(R.id.btnBackArrow).setOnClickListener {
            finish()
        }
        // Set default date to today
        updateDateDisplay()
        etDate.setOnClickListener {
            showDatePicker()
        }

        // Load categories when type changes
        rgType.setOnCheckedChangeListener { _, checkedId ->
            val type = if (checkedId == R.id.rbIncome) "IN" else "OUT"
            loadCategories(type)
        }

        // Load income categories by default
        loadCategories("IN")

        // Manage categories button
        btnManageCategories.setOnClickListener {
            val intent = Intent(this, ManageCategoriesActivity::class.java)
            intent.putExtra("USER_ID", userId)
            startActivity(intent)
        }

        // Save button
        btnSave.setOnClickListener {
            saveTransaction()
        }
    }

    override fun onResume() {
        super.onResume()
        // Reload categories when returning from ManageCategoriesActivity
        val type = if (rbIncome.isChecked) "IN" else "OUT"
        loadCategories(type)
    }

    private fun loadCategories(type: String) {
        val categories = db.getCategoriesByType(userId, type)

        if (categories.isEmpty()) {
            Toast.makeText(this, "No categories found. Add one first!", Toast.LENGTH_SHORT).show()
            spinnerCategory.adapter = null
            return
        }

        spinnerCategory.adapter = ArrayAdapter(
            this,
            android.R.layout.simple_spinner_item,
            categories
        ).apply {
            setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item)
        }
    }

    private fun showDatePicker() {
        DatePickerDialog(
            this,
            { _, year, month, day ->
                calendar.set(year, month, day)
                updateDateDisplay()
            },
            calendar.get(Calendar.YEAR),
            calendar.get(Calendar.MONTH),
            calendar.get(Calendar.DAY_OF_MONTH)
        ).show()
    }

    private fun updateDateDisplay() {
        val dateFormat = SimpleDateFormat("yyyy-MM-dd", Locale.getDefault())
        selectedDate = dateFormat.format(calendar.time)
        etDate.setText(selectedDate)
    }

    private fun saveTransaction() {
        val category = spinnerCategory.selectedItem?.toString()
        val amountStr = etAmount.text.toString().trim()
        val note = etNote.text.toString().trim()

        if (category == null) {
            Toast.makeText(this, "Please select a category", Toast.LENGTH_SHORT).show()
            return
        }

        if (amountStr.isEmpty()) {
            Toast.makeText(this, "Please enter amount", Toast.LENGTH_SHORT).show()
            return
        }

        val amount = amountStr.toDoubleOrNull()
        if (amount == null || amount <= 0) {
            Toast.makeText(this, "Please enter valid amount", Toast.LENGTH_SHORT).show()
            return
        }

        val type = if (rbIncome.isChecked) "IN" else "OUT"

        db.insertTransaction(
            userId = userId,
            date = selectedDate,
            category = category,
            type = type,
            amount = amount,
            note = note
        )

        Toast.makeText(this, "Transaction saved!", Toast.LENGTH_SHORT).show()

        etAmount.setText("")
        etNote.setText("")

        finish()
    }

    override fun onSupportNavigateUp(): Boolean {
        finish()
        return true
    }
}