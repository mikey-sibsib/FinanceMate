package com.example.financemate

import android.os.Bundle
import android.widget.*
import androidx.appcompat.app.AppCompatActivity
import java.text.NumberFormat
import java.text.SimpleDateFormat
import java.util.*

class ViewTransactionsActivity : AppCompatActivity() {

    private lateinit var db: DatabaseHelper
    private var userId: Int = -1

    private lateinit var spinnerFilter: Spinner
    private lateinit var spinnerCategory: Spinner
    private lateinit var listView: ListView
    private lateinit var tvTotal: TextView

    private var allTransactions = listOf<TransactionExport>()
    private var allCategories = listOf<String>()
    private var isInitialLoad = true

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_view_transactions)

        supportActionBar?.setDisplayHomeAsUpEnabled(true)
        supportActionBar?.title = "All Transactions"

        db = DatabaseHelper(this)

        userId = intent.getIntExtra("USER_ID", -1)
        if (userId == -1) {
            Toast.makeText(this, "Error: User not found", Toast.LENGTH_SHORT).show()
            finish()
            return
        }

        spinnerFilter = findViewById(R.id.spinnerFilter)
        spinnerCategory = findViewById(R.id.spinnerCategory)
        listView = findViewById(R.id.listTransactions)
        tvTotal = findViewById(R.id.tvTotal)

        findViewById<Button>(R.id.btnBackArrow).setOnClickListener {
            finish()
        }

        allTransactions = db.getAllTransactions(userId)

        val incomeCategories = db.getCategoriesByType(userId, "IN")
        val expenseCategories = db.getCategoriesByType(userId, "OUT")
        allCategories = (listOf("All Categories") + incomeCategories + expenseCategories).distinct()

        if (allTransactions.isEmpty()) {
            Toast.makeText(this, "No transactions yet. Add some first!", Toast.LENGTH_LONG).show()

        } else {
            Toast.makeText(this, "Found ${allTransactions.size} transactions", Toast.LENGTH_SHORT).show()
        }

        val filterOptions = arrayOf("All", "Today", "This Week", "This Month", "This Year")
        val spinnerAdapter = ArrayAdapter(
            this,
            android.R.layout.simple_spinner_item,
            filterOptions
        )
        spinnerAdapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item)
        spinnerFilter.adapter = spinnerAdapter

        val categoryAdapter = ArrayAdapter(
            this,
            android.R.layout.simple_spinner_item,
            allCategories
        )
        categoryAdapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item)
        spinnerCategory.adapter = categoryAdapter

        spinnerFilter.onItemSelectedListener = object : AdapterView.OnItemSelectedListener {
            override fun onItemSelected(parent: AdapterView<*>, view: android.view.View?, position: Int, id: Long) {
                if (!isInitialLoad) {
                    applyFilters()
                }
            }

            override fun onNothingSelected(parent: AdapterView<*>) {}
        }

        spinnerCategory.onItemSelectedListener = object : AdapterView.OnItemSelectedListener {
            override fun onItemSelected(parent: AdapterView<*>, view: android.view.View?, position: Int, id: Long) {
                if (!isInitialLoad) {
                    applyFilters()
                }
            }

            override fun onNothingSelected(parent: AdapterView<*>) {}
        }
        
        isInitialLoad = false
        applyFilters()
    }

    private fun applyFilters() {
        val timeFilter = spinnerFilter.selectedItem.toString()
        val categoryFilter = spinnerCategory.selectedItem.toString()

        var filtered = when (timeFilter) {
            "Today" -> filterByToday()
            "This Week" -> filterByWeek()
            "This Month" -> filterByMonth()
            "This Year" -> filterByYear()
            else -> allTransactions
        }

        // Apply category filter
        if (categoryFilter != "All Categories") {
            filtered = filtered.filter { it.category == categoryFilter }
        }

        displayTransactions(filtered)
    }

    private fun filterByToday(): List<TransactionExport> {
        val today = SimpleDateFormat("yyyy-MM-dd", Locale.getDefault()).format(Date())
        return allTransactions.filter { it.date == today }
    }

    private fun filterByWeek(): List<TransactionExport> {
        val calendar = Calendar.getInstance()
        calendar.set(Calendar.DAY_OF_WEEK, calendar.firstDayOfWeek)
        val weekStart = SimpleDateFormat("yyyy-MM-dd", Locale.getDefault()).format(calendar.time)

        return allTransactions.filter { it.date >= weekStart }
    }

    private fun filterByMonth(): List<TransactionExport> {
        val calendar = Calendar.getInstance()
        val currentMonth = SimpleDateFormat("yyyy-MM", Locale.getDefault()).format(calendar.time)

        return allTransactions.filter { it.date.startsWith(currentMonth) }
    }

    private fun filterByYear(): List<TransactionExport> {
        val calendar = Calendar.getInstance()
        val currentYear = SimpleDateFormat("yyyy", Locale.getDefault()).format(calendar.time)

        return allTransactions.filter { it.date.startsWith(currentYear) }
    }

    private fun displayTransactions(transactions: List<TransactionExport>) {
        val formatter = NumberFormat.getCurrencyInstance(Locale("id", "ID"))

        if (transactions.isEmpty()) {
            listView.adapter = null
            tvTotal.text = "No transactions found"
            return
        }

        // Calculate totals
        var totalIncome = 0.0
        var totalExpense = 0.0

        val displayList = transactions.map { transaction ->
            val typeIcon = if (transaction.type == "IN") "💰" else "💸"
            val typeText = if (transaction.type == "IN") "Income" else "Expense"

            if (transaction.type == "IN") {
                totalIncome += transaction.amount
            } else {
                totalExpense += transaction.amount
            }

            "$typeIcon ${transaction.date}\n${transaction.category} - $typeText\n${formatter.format(transaction.amount)}\nNote: ${transaction.note}"
        }

        listView.adapter = ArrayAdapter(
            this,
            android.R.layout.simple_list_item_1,
            displayList
        )

        // Display total
        val balance = totalIncome - totalExpense
        tvTotal.text = "Income: ${formatter.format(totalIncome)} | Expense: ${formatter.format(totalExpense)} " +
                "| Balance: ${formatter.format(balance)}"
    }

    override fun onSupportNavigateUp(): Boolean {
        finish()
        return true
    }
}