package com.example.financemate

import android.os.Bundle
import android.widget.*
import androidx.appcompat.app.AppCompatActivity

class AddCategoryActivity : AppCompatActivity() {

    private lateinit var db: DatabaseHelper
    private var userId: Int = -1

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_add_category)

        // Enable back button in action bar
        supportActionBar?.setDisplayHomeAsUpEnabled(true)
        supportActionBar?.title = "Add Category"

        db = DatabaseHelper(this)

        // Get userId from intent
        userId = intent.getIntExtra("USER_ID", -1)
        if (userId == -1) {
            Toast.makeText(this, "Error: User not found", Toast.LENGTH_SHORT).show()
            finish()
            return
        }

        val etName = findViewById<EditText>(R.id.etCategoryName)
        val rgType = findViewById<RadioGroup>(R.id.rgCategoryType)
        val btnSave = findViewById<Button>(R.id.btnSaveCategory)
        val btnBack = findViewById<Button>(R.id.btnBack)

        // Back arrow button
        findViewById<Button>(R.id.btnBackArrow).setOnClickListener {
            finish()
        }

        // ================= SAVE CATEGORY =================
        btnSave.setOnClickListener {

            val name = etName.text.toString().trim()

            if (name.isEmpty()) {
                Toast.makeText(this, "Category name cannot be empty", Toast.LENGTH_SHORT).show()
                return@setOnClickListener
            }

            val type = when (rgType.checkedRadioButtonId) {
                R.id.rbIncome -> "IN"
                R.id.rbExpense -> "OUT"
                else -> null
            }

            if (type == null) {
                Toast.makeText(this, "Select category type", Toast.LENGTH_SHORT).show()
                return@setOnClickListener
            }

            try {
                db.insertCategory(userId, name, type)
                Toast.makeText(this, "Category added", Toast.LENGTH_SHORT).show()
                finish()
            } catch (e: Exception) {
                Toast.makeText(this, "Failed to add category", Toast.LENGTH_SHORT).show()
            }
        }
        btnBack.setOnClickListener {
            finish()
        }
    }

    override fun onSupportNavigateUp(): Boolean {
        finish()
        return true
    }
}