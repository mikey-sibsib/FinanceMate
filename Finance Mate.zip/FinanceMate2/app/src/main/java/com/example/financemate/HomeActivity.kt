package com.example.financemate

import android.content.Intent
import android.os.Bundle
import android.widget.*
import androidx.appcompat.app.AppCompatActivity
import java.text.NumberFormat
import java.util.*

class HomeActivity : AppCompatActivity() {

    private lateinit var db: DatabaseHelper
    private var userId: Int = -1

    private lateinit var tvIncome: TextView
    private lateinit var tvExpense: TextView
    private lateinit var tvBalance: TextView
    private lateinit var btnAddTransaction: Button
    private lateinit var btnViewTransactions: Button
    private lateinit var btnCategorySummary: Button
    private lateinit var btnViewGraphs: Button
    private lateinit var btnExport: Button
    private lateinit var btnLogout: Button

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_home)

        db = DatabaseHelper(this)

        // Get userId from intent
        userId = intent.getIntExtra("USER_ID", -1)
        if (userId == -1) {
            Toast.makeText(this, "Error: User not found", Toast.LENGTH_SHORT).show()
            finish()
            return
        }

        // Initialize views
        tvIncome = findViewById(R.id.tvIncome)
        tvExpense = findViewById(R.id.tvExpense)
        tvBalance = findViewById(R.id.tvBalance)
        btnAddTransaction = findViewById(R.id.btnAddTransaction)
        btnViewTransactions = findViewById(R.id.btnViewTransactions)
        btnCategorySummary = findViewById(R.id.btnCategorySummary)
        btnViewGraphs = findViewById(R.id.btnViewGraphs)
        btnExport = findViewById(R.id.btnExport)
        btnLogout = findViewById(R.id.btnLogout)

        // Load summary
        loadSummary()

        // Button listeners
        btnAddTransaction.setOnClickListener {
            val intent = Intent(this, AddTransactionActivity::class.java)
            intent.putExtra("USER_ID", userId)
            startActivity(intent)
        }

        btnViewTransactions.setOnClickListener {
            val intent = Intent(this, ViewTransactionsActivity::class.java)
            intent.putExtra("USER_ID", userId)
            startActivity(intent)
        }

        btnCategorySummary.setOnClickListener {
            val intent = Intent(this, CategorySummaryActivity::class.java)
            intent.putExtra("USER_ID", userId)
            startActivity(intent)
        }

        btnViewGraphs.setOnClickListener {
            val intent = Intent(this, GraphActivity::class.java)
            intent.putExtra("USER_ID", userId)
            startActivity(intent)
        }

        btnExport.setOnClickListener {
            val intent = Intent(this, ExportPdfActivity::class.java)
            intent.putExtra("USER_ID", userId)
            startActivity(intent)
        }

        btnLogout.setOnClickListener {
            // Clear any session data if needed
            val intent = Intent(this, MainActivity::class.java)
            intent.flags = Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TASK
            startActivity(intent)
            finish()
        }
    }

    override fun onResume() {
        super.onResume()
        loadSummary()
    }

    private fun loadSummary() {
        val income = db.getTotalIncome(userId)
        val expense = db.getTotalExpense(userId)
        val balance = income - expense

        val formatter = NumberFormat.getCurrencyInstance(Locale("id", "ID"))

        tvIncome.text = "Income: ${formatter.format(income)}"
        tvExpense.text = "Expense: ${formatter.format(expense)}"
        tvBalance.text = "Balance: ${formatter.format(balance)}"
    }
}