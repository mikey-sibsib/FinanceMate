package com.example.financemate

import android.os.Bundle
import android.widget.Button
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity

class ExportPdfActivity : AppCompatActivity() {

    private lateinit var db: DatabaseHelper
    private var userId: Int = -1

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_export_pdf)

        // Enable back button
        supportActionBar?.setDisplayHomeAsUpEnabled(true)
        supportActionBar?.title = "Export PDF"

        db = DatabaseHelper(this)

        // Get userId
        userId = intent.getIntExtra("USER_ID", -1)
        if (userId == -1) {
            Toast.makeText(this, "Error: User not found", Toast.LENGTH_SHORT).show()
            finish()
            return
        }

        // Back button
        findViewById<Button>(R.id.btnBackArrow).setOnClickListener {
            finish()
        }

        findViewById<Button>(R.id.btnExportPdf).setOnClickListener {
            val transactions = db.getAllTransactions(userId)

            if (transactions.isEmpty()) {
                Toast.makeText(this, "No transactions to export", Toast.LENGTH_SHORT).show()
                return@setOnClickListener
            }

            val file = PdfExporter.export(this, transactions)
            Toast.makeText(this, "PDF exported to: ${file.absolutePath}", Toast.LENGTH_LONG).show()
        }
    }

    override fun onSupportNavigateUp(): Boolean {
        finish()
        return true
    }
}