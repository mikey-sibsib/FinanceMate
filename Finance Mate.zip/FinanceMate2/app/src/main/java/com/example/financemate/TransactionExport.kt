package com.example.financemate

data class TransactionExport(
    val date: String,
    val category: String,
    val type: String,
    val amount: Double,
    val note: String
)