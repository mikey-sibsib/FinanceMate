package com.example.financemate

import android.graphics.Color
import android.os.Bundle
import android.view.View
import android.widget.*
import androidx.appcompat.app.AppCompatActivity
import kotlin.math.absoluteValue

class GraphActivity : AppCompatActivity() {

    private lateinit var db: DatabaseHelper
    private var userId: Int = -1

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_graph)

        // Enable back button
        supportActionBar?.setDisplayHomeAsUpEnabled(true)
        supportActionBar?.title = "Financial Graphs"

        db = DatabaseHelper(this)

        // Get userId
        userId = intent.getIntExtra("USER_ID", -1)
        if (userId == -1) {
            Toast.makeText(this, "Error: User not found", Toast.LENGTH_SHORT).show()
            finish()
            return
        }
        // Back button
        findViewById<Button>(R.id.btnBackArrow).setOnClickListener {
            finish()
        }
        // Load data and create graphs
        loadGraphs()
    }

    private fun loadGraphs() {
        val transactions = db.getAllTransactions(userId)

        if (transactions.isEmpty()) {
            Toast.makeText(this, "No data to display. Add transactions first!", Toast.LENGTH_LONG).show()
            return
        }

        // Calculate totals
        var totalIncome = 0.0
        var totalExpense = 0.0
        val expenseByCategory = mutableMapOf<String, Double>()

        transactions.forEach { transaction ->
            if (transaction.type == "IN") {
                totalIncome += transaction.amount
            } else {
                totalExpense += transaction.amount
                val currentAmount = expenseByCategory[transaction.category] ?: 0.0
                expenseByCategory[transaction.category] = currentAmount + transaction.amount
            }
        }

        // Display simple bar representation
        displayIncomeExpenseBar(totalIncome, totalExpense)

        // Display category breakdown
        displayCategoryBreakdown(expenseByCategory, totalExpense)
    }

    private fun displayIncomeExpenseBar(income: Double, expense: Double) {
        val barIncome = findViewById<View>(R.id.barIncome)
        val barExpense = findViewById<View>(R.id.barExpense)
        val tvIncomeAmount = findViewById<TextView>(R.id.tvIncomeAmount)
        val tvExpenseAmount = findViewById<TextView>(R.id.tvExpenseAmount)

        // Calculate max for scaling
        val max = maxOf(income, expense)

        if (max > 0) {
            val incomeHeight = ((income / max) * 300).toInt()
            val expenseHeight = ((expense / max) * 300).toInt()

            val incomeParams = barIncome.layoutParams
            incomeParams.height = incomeHeight
            barIncome.layoutParams = incomeParams

            val expenseParams = barExpense.layoutParams
            expenseParams.height = expenseHeight
            barExpense.layoutParams = expenseParams

            barIncome.requestLayout()
            barExpense.requestLayout()
        }

        val formatter = java.text.NumberFormat.getCurrencyInstance(java.util.Locale("id", "ID"))
        tvIncomeAmount.text = formatter.format(income)
        tvExpenseAmount.text = formatter.format(expense)
    }

    private fun displayCategoryBreakdown(categoryMap: Map<String, Double>, total: Double) {
        val container = findViewById<LinearLayout>(R.id.categoryBreakdownContainer)
        container.removeAllViews()

        if (total == 0.0) {
            val emptyText = TextView(this)
            emptyText.text = getString(android.R.string.no)
            emptyText.setTextColor(Color.GRAY)
            container.addView(emptyText)
            return
        }

        // Sort by amount descending
        val sortedCategories = categoryMap.entries.sortedByDescending { it.value }
        val formatter = java.text.NumberFormat.getCurrencyInstance(java.util.Locale("id", "ID"))

        sortedCategories.forEach { (category, amount) ->
            val percentage = (amount / total * 100)

            // Create category row
            val rowLayout = LinearLayout(this).apply {
                orientation = LinearLayout.VERTICAL
                setPadding(0, 16, 0, 16)
            }

            // Category name and amount
            val infoLayout = LinearLayout(this).apply {
                orientation = LinearLayout.HORIZONTAL
            }

            val nameText = TextView(this).apply {
                text = category
                textSize = 16f
                setTextColor(Color.parseColor("#2C3E50"))
                layoutParams = LinearLayout.LayoutParams(
                    0,
                    LinearLayout.LayoutParams.WRAP_CONTENT,
                    1f
                )
            }

            val amountText = TextView(this).apply {
                text = String.format(java.util.Locale.getDefault(), "%s (%.1f%%)",
                    formatter.format(amount), percentage)
                textSize = 14f
                setTextColor(Color.parseColor("#7F8C8D"))
            }

            infoLayout.addView(nameText)
            infoLayout.addView(amountText)

            // Progress bar
            val progressBar = View(this).apply {
                setBackgroundColor(getColorForCategory(category))
                layoutParams = LinearLayout.LayoutParams(
                    (percentage * 3).toInt().coerceAtLeast(10),
                    20
                )
            }

            rowLayout.addView(infoLayout)
            rowLayout.addView(progressBar)

            container.addView(rowLayout)
        }
    }

    private fun getColorForCategory(category: String): Int {
        val colors = listOf(
            Color.parseColor("#3674B5"),
            Color.parseColor("#578FCA"),
            Color.parseColor("#E74C3C"),
            Color.parseColor("#F39C12"),
            Color.parseColor("#27AE60"),
            Color.parseColor("#8E44AD"),
            Color.parseColor("#E67E22")
        )
        return colors[category.hashCode().absoluteValue % colors.size]
    }

    override fun onSupportNavigateUp(): Boolean {
        finish()
        return true
    }
}