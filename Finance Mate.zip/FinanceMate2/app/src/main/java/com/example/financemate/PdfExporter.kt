package com.example.financemate

import android.content.ContentValues
import android.content.Context
import android.graphics.Paint
import android.graphics.pdf.PdfDocument
import android.net.Uri
import android.os.Build
import android.provider.MediaStore
import java.io.File
import java.io.OutputStream
import java.text.NumberFormat
import java.util.*

object PdfExporter {

    fun export(context: Context, data: List<TransactionExport>): File {
        val pdf = PdfDocument()
        val paint = Paint()
        val formatter = NumberFormat.getCurrencyInstance(Locale("id", "ID"))

        paint.textSize = 12f

        var pageNumber = 1
        var y = 40

        var page = pdf.startPage(
            PdfDocument.PageInfo.Builder(595, 842, pageNumber).create()
        )

        val canvas = page.canvas

        paint.textSize = 18f
        canvas.drawText("FinanceMate - Transaction Report", 40f, y.toFloat(), paint)
        y += 30

        paint.textSize = 12f
        
        canvas.drawText("Date", 40f, y.toFloat(), paint)
        canvas.drawText("Category", 120f, y.toFloat(), paint)
        canvas.drawText("Type", 240f, y.toFloat(), paint)
        canvas.drawText("Amount", 320f, y.toFloat(), paint)
        canvas.drawText("Note", 420f, y.toFloat(), paint)
        y += 20

        for (item in data) {

            if (y > 800) {
                pdf.finishPage(page)
                pageNumber++
                page = pdf.startPage(
                    PdfDocument.PageInfo.Builder(595, 842, pageNumber).create()
                )
                y = 40
            }

            val typeText = if (item.type == "IN") "Income" else "Expense"

            canvas.drawText(item.date, 40f, y.toFloat(), paint)
            canvas.drawText(item.category, 120f, y.toFloat(), paint)
            canvas.drawText(typeText, 240f, y.toFloat(), paint)
            canvas.drawText(formatter.format(item.amount), 320f, y.toFloat(), paint)
            canvas.drawText(item.note, 420f, y.toFloat(), paint)

            y += 20
        }

        pdf.finishPage(page)

        // Save to app's external files directory
        val file = File(context.getExternalFilesDir(null), "transactions.pdf")
        pdf.writeTo(file.outputStream())
        pdf.close()

        return file
    }

    // Alternative method that saves to MediaStore (for user's Documents folder)
    fun exportToDocuments(
        context: Context,
        fileName: String,
        data: List<TransactionExport>
    ): Uri? {
        val pdf = PdfDocument()
        val paint = Paint()
        val formatter = NumberFormat.getCurrencyInstance(Locale("id", "ID"))

        paint.textSize = 12f

        var pageNumber = 1
        var y = 40

        var page = pdf.startPage(
            PdfDocument.PageInfo.Builder(595, 842, pageNumber).create()
        )

        val canvas = page.canvas

        paint.textSize = 18f
        canvas.drawText("FinanceMate - Transaction Report", 40f, y.toFloat(), paint)
        y += 30

        paint.textSize = 12f

        for (item in data) {
            if (y > 800) {
                pdf.finishPage(page)
                pageNumber++
                page = pdf.startPage(
                    PdfDocument.PageInfo.Builder(595, 842, pageNumber).create()
                )
                y = 40
            }

            val typeText = if (item.type == "IN") "Income" else "Expense"
            canvas.drawText(
                "${item.date} | ${item.category} | $typeText | ${formatter.format(item.amount)}",
                40f,
                y.toFloat(),
                paint
            )
            y += 20
        }

        pdf.finishPage(page)

        val uri = savePdfToMediaStore(context, fileName, pdf)
        pdf.close()
        return uri
    }

    private fun savePdfToMediaStore(context: Context, fileName: String, pdf: PdfDocument): Uri? {
        val resolver = context.contentResolver

        val contentValues = ContentValues().apply {
            put(MediaStore.MediaColumns.DISPLAY_NAME, "$fileName.pdf")
            put(MediaStore.MediaColumns.MIME_TYPE, "application/pdf")
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
                put(MediaStore.MediaColumns.RELATIVE_PATH, "Documents/FinanceMate")
            }
        }

        val uri = resolver.insert(
            MediaStore.Files.getContentUri("external"),
            contentValues
        ) ?: return null

        val output: OutputStream? = resolver.openOutputStream(uri)
        pdf.writeTo(output)
        output?.close()

        return uri
    }
}