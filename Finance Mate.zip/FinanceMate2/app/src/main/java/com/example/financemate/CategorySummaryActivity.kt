package com.example.financemate

import android.os.Bundle
import android.widget.*
import androidx.appcompat.app.AppCompatActivity
import java.text.NumberFormat
import java.util.*

class CategorySummaryActivity : AppCompatActivity() {

    private lateinit var db: DatabaseHelper
    private var userId: Int = -1

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_category_summary)

        // Enable back button
        supportActionBar?.setDisplayHomeAsUpEnabled(true)
        supportActionBar?.title = "Category Summary"

        db = DatabaseHelper(this)

        // Get userId
        userId = intent.getIntExtra("USER_ID", -1)
        if (userId == -1) {
            Toast.makeText(this, "Error: User not found", Toast.LENGTH_SHORT).show()
            finish()
            return
        }

        val listView = findViewById<ListView>(R.id.listCategory)
        val radioGroup = findViewById<RadioGroup>(R.id.rgType)

        // Back button
        findViewById<Button>(R.id.btnBackArrow).setOnClickListener {
            finish()
        }

        // Load income summary by default
        radioGroup.check(R.id.rbIn)
        loadSummary("IN", listView)

        // Switch between Income and Expense
        radioGroup.setOnCheckedChangeListener { _, checkedId ->
            val type = if (checkedId == R.id.rbIn) "IN" else "OUT"
            loadSummary(type, listView)
        }
    }

    /**
     * Loads category totals and calculates percentage breakdown
     */
    private fun loadSummary(type: String, listView: ListView) {

        val data = db.getTotalByCategory(userId, type)

        val formatter = NumberFormat.getCurrencyInstance(Locale("id", "ID"))

        if (data.isEmpty()) {
            listView.adapter = null
            Toast.makeText(this, "No data available", Toast.LENGTH_SHORT).show()
            return
        }

        // Calculate overall total
        val overallTotal = data.sumOf { it.total }

        //Create display list with percentage calculation
        val displayList = data.map { item ->

            val percentage = if (overallTotal > 0) {
                (item.total / overallTotal) * 100
            } else {
                0.0
            }
            val formattedPercentage = String.format("%.1f", percentage)
            "${item.categoryName} : ${formatter.format(item.total)} ($formattedPercentage%)"
        }

        //Display results in scrollable ListView
        listView.adapter = ArrayAdapter(
            this,
            android.R.layout.simple_list_item_1,
            displayList
        )
    }

    override fun onSupportNavigateUp(): Boolean {
        finish()
        return true
    }
}