package com.example.financemate

import android.content.ContentValues
import android.content.Context
import android.database.sqlite.SQLiteDatabase
import android.database.sqlite.SQLiteOpenHelper

class DatabaseHelper(context: Context) :
    SQLiteOpenHelper(context, "financemate.db", null, 3) {

    override fun onCreate(db: SQLiteDatabase) {
        // Users table
        db.execSQL(
            """
            CREATE TABLE users(
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                username TEXT UNIQUE,
                password TEXT
            )
            """
        )

        // Transactions table with userId
        db.execSQL(
            """
            CREATE TABLE transactions(
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                userId INTEGER,
                date TEXT,
                category TEXT,
                type TEXT,
                amount REAL,
                note TEXT,
                FOREIGN KEY(userId) REFERENCES users(id)
            )
            """
        )

        // Categories table with userId
        db.execSQL(
            """
            CREATE TABLE categories(
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                userId INTEGER,
                name TEXT,
                type TEXT,
                FOREIGN KEY(userId) REFERENCES users(id)
            )
            """
        )
    }

    override fun onUpgrade(db: SQLiteDatabase, oldVersion: Int, newVersion: Int) {
        // Simple upgrade - just recreate tables
        // In production, you'd want to preserve user data
        if (oldVersion < 3) {
            try {
                db.execSQL("DROP TABLE IF EXISTS transactions")
                db.execSQL("DROP TABLE IF EXISTS categories")
                db.execSQL("DROP TABLE IF EXISTS users")
                onCreate(db)
            } catch (e: Exception) {
                e.printStackTrace()
            }
        }
    }

    // ========== USER METHODS ==========

    fun registerUser(username: String, password: String): Boolean {
        return try {
            val cv = ContentValues()
            cv.put("username", username)
            cv.put("password", password)
            writableDatabase.insert("users", null, cv) != -1L
        } catch (e: Exception) {
            false
        }
    }

    fun loginUser(username: String, password: String): Int {
        val cursor = readableDatabase.rawQuery(
            "SELECT id FROM users WHERE username=? AND password=?",
            arrayOf(username, password)
        )
        var userId = -1
        if (cursor.moveToFirst()) {
            userId = cursor.getInt(0)
        }
        cursor.close()
        return userId
    }

    fun getUserHash(username: String): String? {
        val cursor = readableDatabase.rawQuery(
            "SELECT password FROM users WHERE username=?",
            arrayOf(username)
        )
        var hash: String? = null
        if (cursor.moveToFirst()) {
            hash = cursor.getString(0)
        }
        cursor.close()
        return hash
    }

    fun getUserId(username: String): Int? {
        val cursor = readableDatabase.rawQuery(
            "SELECT id FROM users WHERE username=?",
            arrayOf(username)
        )
        var id: Int? = null
        if (cursor.moveToFirst()) {
            id = cursor.getInt(0)
        }
        cursor.close()
        return id
    }

    fun insertUser(username: String, passwordHash: String): Boolean {
        return try {
            val cv = ContentValues()
            cv.put("username", username)
            cv.put("password", passwordHash)
            val result = writableDatabase.insert("users", null, cv)

            // If user created successfully, get userId and insert default categories
            if (result != -1L) {
                val userId = result.toInt()
                insertDefaultCategories(userId)
                true
            } else {
                false
            }
        } catch (e: Exception) {
            false
        }
    }

    // ========== TRANSACTION METHODS ==========

    fun insertTransaction(
        userId: Int,
        date: String,
        category: String,
        type: String,
        amount: Double,
        note: String
    ) {
        val cv = ContentValues()
        cv.put("userId", userId)
        cv.put("date", date)
        cv.put("category", category)
        cv.put("type", type)
        cv.put("amount", amount)
        cv.put("note", note)
        writableDatabase.insert("transactions", null, cv)
    }

    fun getAllTransactions(userId: Int): List<TransactionExport> {
        val list = mutableListOf<TransactionExport>()
        try {
            val cursor = readableDatabase.rawQuery(
                "SELECT date, category, type, amount, note FROM transactions WHERE userId=? ORDER BY date DESC",
                arrayOf(userId.toString())
            )
            while (cursor.moveToNext()) {
                list.add(
                    TransactionExport(
                        cursor.getString(0),
                        cursor.getString(1),
                        cursor.getString(2),
                        cursor.getDouble(3),
                        cursor.getString(4)
                    )
                )
            }
            cursor.close()
        } catch (e: Exception) {
            e.printStackTrace()
        }
        return list
    }

    fun getTransactionsByCategory(userId: Int, category: String): List<TransactionExport> {
        val list = mutableListOf<TransactionExport>()
        val cursor = readableDatabase.rawQuery(
            "SELECT date, category, type, amount, note FROM transactions WHERE userId=? AND category=? ORDER BY date DESC",
            arrayOf(userId.toString(), category)
        )
        while (cursor.moveToNext()) {
            list.add(
                TransactionExport(
                    cursor.getString(0),
                    cursor.getString(1),
                    cursor.getString(2),
                    cursor.getDouble(3),
                    cursor.getString(4)
                )
            )
        }
        cursor.close()
        return list
    }

    fun getTotalByCategory(userId: Int, type: String): List<CategorySummary> {
        val list = mutableListOf<CategorySummary>()
        val cursor = readableDatabase.rawQuery(
            """
            SELECT category, SUM(amount)
            FROM transactions
            WHERE userId=? AND type=?
            GROUP BY category
            """,
            arrayOf(userId.toString(), type)
        )
        while (cursor.moveToNext()) {
            list.add(CategorySummary(cursor.getString(0), cursor.getDouble(1)))
        }
        cursor.close()
        return list
    }

    fun getTotalIncome(userId: Int): Double {
        val cursor = readableDatabase.rawQuery(
            "SELECT SUM(amount) FROM transactions WHERE userId=? AND type='IN'",
            arrayOf(userId.toString())
        )
        var total = 0.0
        if (cursor.moveToFirst()) {
            total = cursor.getDouble(0)
        }
        cursor.close()
        return total
    }

    fun getTotalExpense(userId: Int): Double {
        val cursor = readableDatabase.rawQuery(
            "SELECT SUM(amount) FROM transactions WHERE userId=? AND type='OUT'",
            arrayOf(userId.toString())
        )
        var total = 0.0
        if (cursor.moveToFirst()) {
            total = cursor.getDouble(0)
        }
        cursor.close()
        return total
    }

    // ========== CATEGORY METHODS ==========

    fun getCategoriesByType(userId: Int, type: String): List<String> {
        val list = mutableListOf<String>()
        val cursor = readableDatabase.rawQuery(
            "SELECT name FROM categories WHERE userId=? AND type=? ORDER BY name",
            arrayOf(userId.toString(), type)
        )
        while (cursor.moveToNext()) {
            list.add(cursor.getString(0))
        }
        cursor.close()
        return list
    }

    fun insertCategory(userId: Int, name: String, type: String) {
        val cv = ContentValues()
        cv.put("userId", userId)
        cv.put("name", name)
        cv.put("type", type)
        writableDatabase.insert("categories", null, cv)
    }

    fun deleteCategory(userId: Int, name: String, type: String) {
        writableDatabase.delete(
            "categories",
            "userId=? AND name=? AND type=?",
            arrayOf(userId.toString(), name, type)
        )
    }

    fun insertDefaultCategories(userId: Int) {
        insertCategory(userId, "Purchase", "IN")
        insertCategory(userId, "Bonus", "IN")
        insertCategory(userId, "Fuel", "OUT")
        insertCategory(userId, "Materials", "OUT")
    }
}