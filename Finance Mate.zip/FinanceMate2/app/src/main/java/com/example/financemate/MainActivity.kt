package com.example.financemate

import android.content.Intent
import android.os.Bundle
import android.util.Log
import android.widget.Button
import android.widget.EditText
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import java.security.MessageDigest

class MainActivity : AppCompatActivity() {

    private lateinit var db: DatabaseHelper
    private lateinit var etUsername: EditText
    private lateinit var etPassword: EditText
    private lateinit var btnLogin: Button
    private lateinit var btnGoToSignup: Button

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        try {
            setContentView(R.layout.activity_main)

            Log.d("MainActivity", "Layout set successfully")

            // Bind UI elements FIRST
            etUsername = findViewById(R.id.etUsername)
            etPassword = findViewById(R.id.etPassword)
            btnLogin = findViewById(R.id.btnLogin)
            btnGoToSignup = findViewById(R.id.btnGoToSignup)

            Log.d("MainActivity", "UI elements bound successfully")

            // Set listeners
            btnLogin.setOnClickListener { handleLogin() }
            btnGoToSignup.setOnClickListener { navigateToSignup() }

            // Initialize database LAST (this is the slow part)
            db = DatabaseHelper(this)

            Log.d("MainActivity", "Database initialized successfully")

        } catch (e: Exception) {
            Log.e("MainActivity", "Error in onCreate: ${e.message}", e)
            Toast.makeText(this, "Error: ${e.message}", Toast.LENGTH_LONG).show()
        }
    }

    private fun handleLogin() {
        try {
            val username = etUsername.text.toString().trim()
            val password = etPassword.text.toString()
            // Validate input
            if (username.isEmpty() || password.isEmpty()) {
                Toast.makeText(this, "Please fill in all fields", Toast.LENGTH_SHORT).show()
                return
            }
            Log.d("MainActivity", "Attempting login for user: $username")
            // Retrieve stored password hash
            val storedHash = db.getUserHash(username)
            if (storedHash == null) {
                Toast.makeText(this, "Invalid username or password", Toast.LENGTH_SHORT).show()
                return
            }
            // Compare hashes
            val inputHash = sha256(password)
            if (inputHash == storedHash) {
                Toast.makeText(this, "Login successful!", Toast.LENGTH_SHORT).show()
                val userId = db.getUserId(username)
                if (userId == null) {
                    Toast.makeText(this, "Error getting user ID", Toast.LENGTH_SHORT).show()
                    return
                }

                Log.d("MainActivity", "Login successful for userId: $userId")
                val intent = Intent(this, HomeActivity::class.java)
                intent.putExtra("USER_ID", userId)
                intent.putExtra("USERNAME", username)
                startActivity(intent)
                finish()
            } else {
                Toast.makeText(this, "Invalid username or password", Toast.LENGTH_SHORT).show()
            }
        } catch (e: Exception) {
            Log.e("MainActivity", "Error in handleLogin: ${e.message}", e)
            Toast.makeText(this, "Login error: ${e.message}", Toast.LENGTH_LONG).show()
        }
    }

    private fun navigateToSignup() {
        try {
            startActivity(Intent(this, SignupActivity::class.java))
        } catch (e: Exception) {
            Log.e("MainActivity", "Error navigating to signup: ${e.message}", e)
            Toast.makeText(this, "Error: ${e.message}", Toast.LENGTH_SHORT).show()
        }
    }

    private fun sha256(input: String): String {
        return MessageDigest
            .getInstance("SHA-256")
            .digest(input.toByteArray())
            .joinToString("") { "%02x".format(it) }
    }
}